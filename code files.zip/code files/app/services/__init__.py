"""ComicCraft service layer."""
